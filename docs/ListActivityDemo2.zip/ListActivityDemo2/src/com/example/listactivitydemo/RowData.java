package com.example.listactivitydemo;

import android.view.View;
import android.widget.Toast;

/*
 * data of one row
 */
public class RowData {
	String string;
	int checkboxId;
	boolean mChecked = false;
	
	public RowData (String string, int checkboxId) {
		this.string = string;
		this.checkboxId = checkboxId;
	}

	public String toString() {
		return this.string;
	}

	public boolean isChecked() {
		return mChecked;
	}

	public void setChecked(boolean checked) {
		mChecked = checked;
	}
}
