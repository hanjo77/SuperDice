package com.example.listactivitydemo;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class MySimpleExtendedArrayAdapter extends ArrayAdapter<RowData> {
    private final Context context;
    private final RowData[] rowData;

	static class ViewHolder {
		public CheckBox checkBox;
		public TextView text;
	}

	/*
	* Adapter to fetch the strings and images for each row
	*   Make sure you store any per-item state in this adapter, not in the Views which may be recycled upon scrolling
	*/
	public MySimpleExtendedArrayAdapter(Context context, RowData[] rowData) {
	super(context, R.layout.rowlayout, rowData);
	this.context = context;
	this.rowData = rowData;
	}

	@Override
	/*
	* Get a View that displays the data at the specified position in the data set.
	* @param position -- The position of the item within the adapter's data set of the item whose view we want.
	* @param convertView -- The old view to reuse, if possible. Note: You should check that this view is non-null and of an appropriate type before using. If it is not possible to convert this view to display the correct data, this method can create a new view.
	* @param parent -- The parent that this view will eventually be attached to.
	* @return -- A View corresponding to the data at the specified position.
	*/
	public View getView(int position, View convertView, ViewGroup parent) {

		View rowView = convertView;
		RowData row = rowData[position];

		if (rowView == null) {
			// initialize row view
			LayoutInflater vi = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			rowView = vi.inflate(R.layout.rowlayout, parent, false);
		}

		// configure view holder
		ViewHolder viewHolder = new ViewHolder();
		viewHolder.text = (TextView) rowView.findViewById(R.id.text1);
		CheckBox checkBox = (CheckBox) rowView
				.findViewById(R.id.checkbox1);
		checkBox.setChecked(row.isChecked());
		checkBox.setTag(row);
		checkBox.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				CheckBox checkBox = (CheckBox) view;
				MainActivity mainActivity = (MainActivity) context;
				RowData row = (RowData) checkBox.getTag();
				row.setChecked(checkBox.isChecked());
				mainActivity.checkItem(row);
			}
		});
		viewHolder.checkBox = checkBox;
		rowView.setTag(viewHolder);

		// fill data
		ViewHolder holder = (ViewHolder) rowView.getTag();
		String s = row.toString();
		holder.text.setText(s);

		return rowView;
	}
}
