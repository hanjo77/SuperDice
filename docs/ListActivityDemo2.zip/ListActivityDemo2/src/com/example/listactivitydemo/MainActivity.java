package com.example.listactivitydemo;

import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

/*
 * Implements a very simple list activity for demo purposes
 */
public class MainActivity extends ListActivity {
	private int checkedItems = 0;
	private int totalItems = 64;
	private static Toast mToast;

	public void onCreate(Bundle icicle) {
		final int numRows = totalItems;
		super.onCreate(icicle);
		RowData[] rowData = new RowData[numRows];
	    
	    // initialize the array with some data (for demo and debugging purposes only)
	    for (int i=0; i< numRows; i++) {
		    rowData[i] = new RowData("Item " + String.valueOf(i + 1), i);
	    }

			    // construct and register the adapter
		MySimpleExtendedArrayAdapter adapter = new MySimpleExtendedArrayAdapter(this, rowData);

		this.setListAdapter(adapter);
		mToast = Toast.makeText(this, "", Toast.LENGTH_SHORT);
	}

	/*
	* Handle the click on a checkbox and show a Toast with position and item when an item is clicked
	*/

	public void checkItem(RowData rowData) {
		String prefix = "";
		if (rowData.isChecked()) {
			checkedItems++;
		}
		else {
			checkedItems--;
			prefix = "un";
		}
		mToast.setText(rowData.toString() + " " + prefix + "checked, checked " + checkedItems + " of " + totalItems + " items");
		mToast.show();
	}
}